let totalMoney = 0;

let bodyPartPicker = Math.floor(Math.random()*3);

let muscularFingerCount = 0;
let muscularFingerCost = 100;


const B_UPPER_BACK = 0;
const B_MIDDLE_BACK = 1;
const B_LOWER_BACK = 2;

const TEN_PERCENT = 1.10;

const MUSCULAR_MULTIPLIER = 5;

setInterval(RNG, 10000);

setInterval(update, 10);

function RNG() {
    bodyPartPicker = Math.floor(Math.random()*3);
}

function displayInstructions() {
    if (bodyPartPicker == B_UPPER_BACK ){
        document.getElementById("instructions").innerText = "My Upper Back Is Sore, Please Massage It!";
    }
    else if (bodyPartPicker == B_MIDDLE_BACK) {
        document.getElementById("instructions").innerText = "My Middle Back Is Killing Me, Please Releive My Pain!";
    }
    else {
        document.getElementById("instructions").innerText = "My Lower Back Is In Pain, Please Make It Stop!";
    }
}

function upperBack() {
    if (bodyPartPicker == B_UPPER_BACK) {
        moneyEarned();
        document.getElementById("wrongBack").innerText = "";
    }
    else {
        document.getElementById("wrongBack").innerText = "Not There!";
    }
}

function middleBack() {
    if (bodyPartPicker == B_MIDDLE_BACK) {
        moneyEarned();
        document.getElementById("wrongBack").innerText = "";
    }
    else {
        document.getElementById("wrongBack").innerText = "Wrong Back!";
    }
}

function lowerBack() {
    if (bodyPartPicker == B_LOWER_BACK) {
        moneyEarned();
        document.getElementById("wrongBack").innerText = "";
    }
    else {
        document.getElementById("wrongBack").innerText = "You are terrible at this!";
    }
}

function buyMuscularFingers() {
    if (totalMoney >= muscularFingerCost &&  muscularFingerCount < 10) {
        totalMoney -= muscularFingerCost;
        muscularFingerCount += 1;
        muscularFingerCost *= TEN_PERCENT;
    }
}


function update() {
    displayInstructions();
    document.getElementById("moneyDisplay").innerText ="$" + totalMoney.toFixed(2);
    document.getElementById("muscularFingerDisplay").innerText = "Muscular Fingers: " + muscularFingerCount;
    document.getElementById("btnMuscularFinger").innerText = "Buy Muscular Fingers: $" + muscularFingerCost.toFixed(2);   
    if (totalMoney >= muscularFingerCost && muscularFingerCount < 10) {
        document.getElementById("btnMuscularFinger").disabled = false;
    } 
    else if (muscularFingerCount == 10){
        document.getElementById("btnMuscularFinger").innerText = "Maxed Out";
        document.getElementById("btnMuscularFinger").disabled = true;
    }
    else {
        document.getElementById("btnMuscularFinger").disabled = true;

    }

}

function moneyEarned() {
    breakFingerChance = Math.floor(Math.random()*10);
    if (breakFingerChance == 0 && muscularFingerCount > 5) {
        totalMoney -=100;
        document.getElementById("brokenBack").innerText = "MY BACK IS BROKEN!!";
    }
    else {
        totalMoney += muscularFingerCount * MUSCULAR_MULTIPLIER + 1;
        document.getElementById("brokenBack").innerText = "";
    }
}